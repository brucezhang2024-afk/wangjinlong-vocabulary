# 한 걸음 · 韩语闪卡

React + TypeScript 移动端闪卡，使用 ts-fsrs 5.4.2 进行间隔复习。进度使用 localStorage，并可导入 / 导出 JSON 备份。

## 开始使用

需要 Node.js 22 或更高版本。在本目录打开终端：

```sh
npm ci
npm run dev
```

打开终端显示的本地网址。学习时先尝试回忆，再显示释义，选择「忘记 / 困难 / 良好 / 简单」。先复习到期词，再从整本词库随机抽取新词；新词不按难度和单元顺序。同一天抽取顺序保持稳定，评分后接着下一词。每日默认 10 个新词，可在设置里调整至 1–100。键盘：空格翻卡、1–4 评价。撤销按钮恢复最后一次评分之前的进度。

记录只保存在当前网址、当前浏览器中，不自动跨设备同步。清理网站数据会清除进度。请在设置页导出备份，换设备后导入。桌面原有 daily 系统没有真实闪卡评分记录，所以没有将其推送历史当作已掌握进度迁入。

## 词库来源与范围

- 源书：桌面 TOPIK单词 文件夹中的《完全掌握新韩国语能力测试 TOPIK 必备单词乱序版（初级中高级）》，330 页扫描 PDF，没有可复制文本层。
- 原书资料：4433 张卡片。原书主体编号 0001–3000 完整导入；附录 1424 行整理后合并 12 条完全重复记录，形成 1412 张卡片；另保留 21 条旧版补充词。
- 主体按初级 1029、中级 954、高级 1017 条及各 20 个 UNIT 整理。附录与主体可含同词不同义或专题重复，卡片数量不等于去重词形数量。
- 扫描文本经过词形、词性、释义和识别异常复核；缺失译文按韩语原句补译，已发现的原书疑误附校订说明。原书缺少例句的卡片已另行补齐，并注明非原书。本次为一次全书整理校订，不等同于出版级语言审校。
- 保留旧版全部 100 个卡片 ID，学习记录继续关联。旧版搭配和关联资料会单独标注。
- 原 PDF、个人学习历史、OCR 原文不包含在发布项目中。
- 若要增加词条，编辑 `src/vocabulary.json`，每条需唯一且稳定的 id、word、level、pos、definition。已有卡片 id 不应改变，否则会失去关联。

## 部署到 GitHub Pages

1. 登录 GitHub，新建仓库，例如 `korean-flashcards`。选择适合自己的仓库可见性；GitHub Free 的 Pages 可使用公开仓库。正式词库和例句随静态网站对访问者可见。
2. 用 GitHub Desktop 选择 **File → Add Local Repository**，选择本项目文件夹。若提示未初始化，选择创建仓库（不要再嵌套一层同名文件夹）。提交文件后用 **Publish repository** 发布；或使用下方命令推送。
3. 在仓库 **Settings → Pages → Build and deployment → Source** 中选择 **GitHub Actions**。
4. 在 **Actions → Deploy GitHub Pages → Run workflow** 运行；后续推送到 main 会自动测试、构建和部署。
5. 工作流成功后，在 **Settings → Pages** 打开显示的网站网址。项目站点通常为 `https://你的用户名.github.io/korean-flashcards/`。
6. 手机浏览器打开该网址即可学习；iPhone Safari 可通过分享菜单「添加到主屏幕」。更换本地预览网址到线上网址时，需要手动导出、导入学习备份。

若使用命令行，在 GitHub 新建空仓库后执行（替换用户名）：

```sh
git init -b main
git add .
git commit -m "Build Korean flashcard app"
git remote add origin https://github.com/YOUR_USERNAME/korean-flashcards.git
git push -u origin main
```

GitHub 官方说明：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

FSRS 官方说明：https://github.com/open-spaced-repetition/ts-fsrs

## 验证与构建

```sh
npm test
npm run build
```

生产文件输出到 `dist/`。Vite 使用相对资源路径，适用于 GitHub Pages 仓库子路径。GitHub 工作流已包含依赖安装、测试、类型检查、构建与发布。

已取消单词和例句的语音播放。当前不包含账户登录、云同步、离线缓存或后台提醒。

原书无例句的 1186 张卡片已补充韩中双语例句，标注为“补充例句 · 约 TOPIK 4 级（非原书）”。难度是学习参考，不代表官方分级。原书已有例句保持不变。

手机今日学习采用 100dvh 自适应一屏布局，保留 19px 韩语和 16px 中文例句。长词、长例句及来源/关联资料根据实际高度分页，点击切换内容；评分按钮始终在屏幕内。支持 Safari 动态工具栏和安全区域。词库与设置仍可正常滚动浏览。

## TOPIK真题词表收录（2026-10-14）

当前共9732张卡片、9124个独立词形。TOPIK公开真题词表7381条去重后新增5001条；2380条重合词补充例句和两组搭配。6条空格异写经过人工复核按已有词处理。原有4731张卡片的ID、词义、原例句和学习记录保持兼容。

“我的词库”的TOPIK真题筛选按原表编号展示7381条记录，每条仅展示一次，使用原表词形、词性、释义、例句和两组搭配；学习状态关联现有卡片。原词库的专题卡继续保留用于学习。学习继续全词库随机，不增加真题随机模式。来源词表的真题、校订、节选、另选及自编例句标记原样保留；未据此推断词频或题号。
