// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {libraryWords,matchesLibraryQuery,hasLearned} from './library.ts';
import {empty,rate,parseProgress,buildCardAliases} from './learning.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const news=words.filter(w=>w.id.startsWith('YONHAP-'));
test('reviewed news entries appear in the news source view with bilingual examples',()=>{
 assert.equal(news.length,155);
 const view=libraryWords(words,'韩联社新闻报道');assert.equal(view.length,155);
 for(const w of view){assert.ok(w.examples.length&&w.collocations.length);assert.equal(w.learningIds[0],w.id);
  for(const e of w.examples){assert.match(e.source,/非原书/);assert.match(e.kr,/[.!?]$/);assert.match(e.cn,/[。！？]$/);}
 }
 assert.ok(!view.some(w=>['나프타','양극재','음극재','사탐런','국가유산청'].includes(w.word)));
});
test('car owner and borrower are independent homographs with independent progress',()=>{
 const pair=news.filter(w=>w.word==='차주');assert.equal(pair.length,2);
 assert.deepEqual(new Set(pair.map(w=>w.hanja)),new Set(['車主','借主']));
 const p=rate(empty(),pair[0].id,3);assert.ok(hasLearned(pair[0],p));assert.ok(!hasLearned(pair[1],p));
 const restored=parseProgress(JSON.stringify(p),new Set(words.map(w=>w.id)),buildCardAliases(words));assert.ok(hasLearned(pair[0],restored));
});
test('news abbreviations and existing linked expressions remain searchable',()=>{
 for(const [word,q] of [['건강 보험','건보'],['주주 총회','주총'],['일심','1심'],['공정거래위원회','공정위']]){
  assert.ok(matchesLibraryQuery(news.find(w=>w.word===word),q));
 }
 assert.ok(matchesLibraryQuery(words.find(w=>w.word==='솔루션'),'설루션'));
 assert.equal(libraryWords(words,'TOPIK真题').length,7381);
 assert.equal(libraryWords(words,'韩剧台词本').length,504);
});
