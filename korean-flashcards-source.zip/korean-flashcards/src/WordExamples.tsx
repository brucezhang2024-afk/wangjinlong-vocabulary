import type {Word} from './learning';

export function WordExamples({word}:{word:Word}){
 const examples=(items:NonNullable<Word['examples']>)=>items.map((ex,i)=><div className="example" key={i}>
  <div className="sentence" lang="ko">{ex.kr}</div><p>{ex.cn}</p>
  {ex.source&&<small className="example-source">{ex.source}</small>}{ex.grammar&&<small>{ex.grammar}</small>}
 </div>);
 if(!word.senses?.length)return <>{examples(word.examples||[])}</>;
 return <>{word.senses.map((sense,i)=><section className="word-sense" key={sense.senseKey}>
  <h3>{word.senses!.length>1?`${i+1}. `:''}{sense.definition} <small>· {sense.pos}</small></h3>
  <p className="sense-frame" lang="ko">句型与搭配 · {sense.frame}</p>
  {sense.usageNote&&<p className="sense-note">{sense.usageNote}</p>}
  {examples(sense.examples)}
 </section>)}</>;
}
