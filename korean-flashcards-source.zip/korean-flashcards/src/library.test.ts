// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {libraryWords,hasLearned} from './library.ts';
import {empty,rate,queue} from './learning.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
test('TOPIK source view has exactly 7381 numbered entries, in original order',()=>{
 const view=libraryWords(words,'TOPIK真题');
 assert.equal(view.length,7381);
 assert.deepEqual(view.map(w=>w.topikNumber),Array.from({length:7381},(_,i)=>i+1));
 assert.deepEqual(view.slice(0,4).map(w=>w.word),['가게','가격','가공','가공되다']);assert.equal(view.at(-1).word,'황금연휴');
 assert.equal(new Set(view.map(w=>w.word)).size,7381);assert.ok(view.every(w=>w.unit===undefined&&w.sourcePage===undefined));
});
test('overlapping entries display source wording and examples, without changing study cards',()=>{
 const view=libraryWords(words,'TOPIK真题');const all=libraryWords(words,'全部');assert.equal(all.length,words.length);assert.equal(all[0],words[0]);
 const spaced=view.find(w=>w.word==='일기 예보');assert.ok(spaced);assert.ok(words.some(w=>w.word==='일기예보'));
 for(const w of view){assert.equal(w.collocations.length,2);assert.equal(w.examples.length,1);assert.ok(w.examples[0].source.startsWith('TOPIK 公开真题词表 · '));}
});
test('source view reflects learning on any existing duplicate card',()=>{
 const source=libraryWords(words,'TOPIK真题').find(w=>w.learningIds.length>1);assert.ok(source);
 let p=empty();assert.equal(hasLearned(source,p),false);p=rate(p,source.learningIds.at(-1),3);assert.equal(hasLearned(source,p),true);
 assert.ok(words.some(w=>w.id===source.id));
});
test('source browsing does not change random learning queue or normal unit filters',()=>{
 const p=empty(),now=new Date('2026-10-14T08:00:00Z');const before=queue(words,p,now,'device');libraryWords(words,'TOPIK真题','1');assert.deepEqual(queue(words,p,now,'device'),before);
 assert.deepEqual(libraryWords(words,'初级','2'),words.filter(w=>w.level==='初级'&&w.unit===2));
});
test('sense-specific cards do not learn mismatched source examples while source browsing stays complete',()=>{
 const source=libraryWords(words,'TOPIK真题');
 const salt=words.find(w=>w.id==='BOOK-0117');
 assert.equal(salt.definition,'咸');
 assert.ok(salt.examples.every(e=>!e.kr.includes('비틀어 짜는')));
 const sourceSqueeze=source.find(w=>w.word==='짜다');
 assert.ok(sourceSqueeze.examples[0].kr.includes('비틀어 짜는'));
 assert.ok(salt.collocations.every(c=>!c.startsWith('빨래를 짜다')));
 assert.ok(salt.collocations.some(c=>c.startsWith('음식이 짜다')));
});
test('corrected source example is visible and original card identifiers remain intact',()=>{
 const source=libraryWords(words,'TOPIK真题');
 const umami=source.find(w=>w.word==='감칠맛');
 assert.ok(umami.examples[0].kr.includes('기본적인 맛 중 하나로 인정된다'));
 assert.ok(umami.examples[0].source.includes('非原题'));
 const low=words.find(w=>w.id==='BOOK-0108');
 assert.equal(low.examples[0].cn,'买了一双皮鞋，不过鞋跟有点低。');
});
