// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {libraryWords,hasLearned} from './library.ts';
import {empty,rate,queue} from './learning.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
test('TOPIK source view has exactly 7381 numbered entries, in original order',()=>{
 const view=libraryWords(words,'TOPIK真题');
 assert.equal(view.length,7381);
 assert.deepEqual(view.map(w=>w.topikNumber),Array.from({length:7381},(_,i)=>i+1));
 assert.deepEqual(view.slice(0,4).map(w=>w.word),['가게','가격','가공','가공되다']);assert.equal(view.at(-1).word,'황금연휴');
 assert.equal(new Set(view.map(w=>w.word)).size,7381);assert.ok(view.every(w=>w.unit===undefined&&w.sourcePage===undefined));
});
test('overlapping entries display source wording and examples, without changing study cards',()=>{
 const view=libraryWords(words,'TOPIK真题');const all=libraryWords(words,'全部');assert.equal(all.length,words.length);assert.equal(all[0],words[0]);
 const spaced=view.find(w=>w.word==='일기 예보');assert.ok(spaced);assert.ok(words.some(w=>w.word==='일기예보'));
 for(const w of view){assert.equal(w.collocations.length,2);assert.equal(w.examples.length,1);assert.ok(w.examples[0].source.startsWith('TOPIK 公开真题词表 · '));}
});
test('source view reflects learning on any existing duplicate card',()=>{
 const source=libraryWords(words,'TOPIK真题').find(w=>w.learningIds.length>1);assert.ok(source);
 let p=empty();assert.equal(hasLearned(source,p),false);p=rate(p,source.learningIds.at(-1),3);assert.equal(hasLearned(source,p),true);
 assert.ok(words.some(w=>w.id===source.id));
});
test('source browsing does not change random learning queue or normal unit filters',()=>{
 const p=empty(),now=new Date('2026-10-14T08:00:00Z');const before=queue(words,p,now,'device');libraryWords(words,'TOPIK真题','1');assert.deepEqual(queue(words,p,now,'device'),before);
 assert.deepEqual(libraryWords(words,'初级','2'),words.filter(w=>w.level==='初级'&&w.unit===2));
});
test('sense-specific cards do not learn mismatched source examples while source browsing stays complete',()=>{
 const source=libraryWords(words,'TOPIK真题');
 const salt=words.find(w=>w.id==='BOOK-0117');
 assert.equal(salt.definition,'咸');
 assert.ok(salt.examples.every(e=>!e.kr.includes('비틀어 짜는')));
 const sourceSqueeze=source.find(w=>w.word==='짜다');
 assert.ok(sourceSqueeze.examples[0].kr.includes('비틀어 짜는'));
 assert.ok(salt.collocations.every(c=>!c.startsWith('빨래를 짜다')));
 assert.ok(salt.collocations.some(c=>c.startsWith('음식이 짜다')));
});
test('corrected source example is visible and original card identifiers remain intact',()=>{
 const source=libraryWords(words,'TOPIK真题');
 const umami=source.find(w=>w.word==='감칠맛');
 assert.ok(umami.examples[0].kr.includes('기본적인 맛 중 하나로 인정된다'));
 assert.ok(umami.examples[0].source.includes('非原题'));
 const low=words.find(w=>w.id==='BOOK-0108');
 assert.equal(low.examples[0].cn,'买了一双皮鞋，不过鞋跟有点低。');
});
test('corrected appendix headword keeps its ID and no longer links to a different TOPIK verb',()=>{
 const card=words.find(w=>w.id==='APP-318-024');
 assert.equal(card.word,'바뀌다');assert.equal(card.pos,'自动词');assert.equal(card.topikNumber,undefined);
 assert.ok(card.examples[0].kr.includes('시간이 바뀌어서'));assert.ok(card.examples[0].source.includes('非原书'));
 const source=libraryWords(words,'TOPIK真题').find(w=>w.topikNumber===2386);
 assert.equal(source.word,'바꾸다');assert.ok(source.examples[0].kr.includes('생각을 바꾸신'));
 assert.ok(!source.learningIds.includes(card.id));
});
test('coat, visibility and order study cards keep their senses while source browsing preserves broader senses',()=>{
 const source=libraryWords(words,'TOPIK真题');
 for(const [id,wrong] of [['BOOK-0795','배구'],['BOOK-0835','보여 주려고'],['APP-318-064','조상을 공경']]){
  const card=words.find(w=>w.id===id);
  assert.ok(card.examples.every(e=>!e.kr.includes(wrong)));
  assert.ok(source.find(w=>w.topikNumber===card.topikNumber).examples[0].kr.includes(wrong));
 }
 const original=source.find(w=>w.word==='똑바로');
 assert.ok(!original.examples[0].kr.includes('스케이트 날을 똑바로'));
 assert.ok(original.examples[0].source.includes('非原题'));
});

test('TOPIK10000 book view contains only appended reviewed cards and leaves the study pool unchanged',()=>{
 const view=libraryWords(words,'TOPIK10000');
 assert.equal(view.length,3869);assert.ok(view.every(w=>w.source==='TOPIK10000'&&w.topik10000Number&&w.senses?.length));
 assert.equal(libraryWords(words,'TOPIK真题').length,7381);
 const sample=view.find(w=>w.topik10000Number===500);assert.equal(sample.word,'급진적');assert.equal(sample.senses.length,2);
 const p=rate(empty(),words[0].id,3,new Date('2026-10-20T03:00:00Z'));
 const before=queue(words,p,new Date('2026-10-20T08:00:00Z'),'device');libraryWords(words,'TOPIK10000');
 assert.deepEqual(queue(words,p,new Date('2026-10-20T08:00:00Z'),'device'),before);
});
