// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {empty,rate,parseProgress} from './learning.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const legacy=JSON.parse(readFileSync(new URL('./legacy-ids.json',import.meta.url),'utf8'));
test('all 3000 source numbers occur once and retain source categories',()=>{
 const main=words.filter(w=>w.bookNumber);
 assert.equal(main.length,3000);
 assert.deepEqual(main.map(w=>w.bookNumber).sort((a,b)=>a-b),Array.from({length:3000},(_,i)=>i+1));
 assert.deepEqual(['初级','中级','高级'].map(l=>main.filter(w=>w.level===l).length),[1029,954,1017]);
 for(const w of main){assert.ok(w.unit>=1&&w.unit<=20,w.id);assert.ok(w.sourcePage>=14&&w.sourcePage<=305,w.id)}
});
test('cards have stable unique ids and usable text',()=>{
 assert.equal(new Set(words.map(w=>w.id)).size,words.length);
 for(const w of words){assert.match(w.word,/[가-힣]/,w.id);assert.match(w.definition,/[\u4e00-\u9fff]/,w.id);assert.ok(w.pos,w.id);
  for(const e of w.examples||[]){assert.match(e.kr,/[가-힣]/,w.id);assert.match(e.cn,/[\u4e00-\u9fff]/,w.id)}
 }
});
test('all previously published cards preserve their word and learning record',()=>{
 const ids=new Set(words.map(w=>w.id));let p=empty();
 for(const [id,word] of Object.entries(legacy)){assert.equal(words.find(w=>w.id===id)?.word,word,id);p=rate(p,id,3,new Date('2026-10-10T08:00:00Z'))}
 const restored=parseProgress(JSON.stringify(p),ids);assert.equal(Object.keys(restored.cards).length,100);assert.equal(restored.events.length,100);
});

test('all cards include bilingual examples and supplements remain distinguishable',()=>{
 assert.ok(words.every(w=>w.examples?.length>0));
 const supplements=words.flatMap(w=>w.examples).filter(e=>e.source?.includes('补充例句')&&e.source.includes('非原书'));
 // The original 1186 supplements remain covered as corrected replacements gain explicit labels.
 assert.ok(supplements.length>=1186);
 for(const e of words.flatMap(w=>w.examples).filter(e=>e.source?.includes('补充例句'))){
  assert.match(e.source,/非原书|非原题/);
 }
});
