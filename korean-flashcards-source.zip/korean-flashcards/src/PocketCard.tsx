import {useEffect,useLayoutEffect,useMemo,useRef,useState} from 'react';
import type {Word} from './learning';

type Block={kind:string;text:string;lang?:string};
// Split only unusually long text; keep Korean words together where possible.
function parts(text:string,limit=90){
 const result:string[]=[];let rest=text.trim();
 while(rest.length>limit){
  let end=rest.lastIndexOf(' ',limit);
  if(end<limit/2)end=limit;
  result.push(rest.slice(0,end));rest=rest.slice(end).trim();
 }
 if(rest)result.push(rest);return result;
}
export function PocketCard({word,flipped,onFlip}:{word:Word;flipped:boolean;onFlip:()=>void}){
 const stage=useRef<HTMLDivElement>(null),measure=useRef<HTMLDivElement>(null);
 const [pages,setPages]=useState<Block[][]>([]),[page,setPage]=useState(0);
 const blocks=useMemo(()=>{
  const list:Block[]=[];
  const add=(kind:string,text?:string,lang?:string,limit=90)=>{if(text)for(const part of parts(text,limit))list.push({kind,text:part,lang})};
  add('word',word.word,'ko',45);
  if(!flipped)return list;
  if(word.senses?.length){
   for(const [i,sense] of word.senses.entries()){
    add('definition',`${word.senses.length>1?`${i+1}. `:''}${sense.definition}`,'zh',80);
    for(const example of sense.examples){
     add('sentence',example.kr,'ko');add('translation',example.cn,'zh',85);
    }
    if(sense.frame)add('collocation',`常见搭配 · ${sense.frame}`);
   }
  }else{
   add('definition',word.definition,'zh',80);
   for(const example of word.examples||[]){
    add('sentence',example.kr,'ko');add('translation',example.cn,'zh',85);
   }
  }
  for(const item of word.collocations||[])add('collocation',`常见搭配 · ${item}`);
  return list;
 },[word,flipped]);
 useLayoutEffect(()=>{
  const host=stage.current,probe=measure.current;if(!host||!probe)return;
  function layout(){
   if(!host||!probe||host.clientWidth===0||host.clientHeight===0)return;
   const budget=host.clientHeight;
   const next:Block[][]=[];let current:Block[]=[];let used=0;
   Array.from(probe.children).forEach((element,i)=>{
    const height=element.getBoundingClientRect().height;
    if(current.length&&used+height>budget){next.push(current);current=[];used=0}
    current.push(blocks[i]);used+=height;
   });
   if(current.length)next.push(current);
   setPages(next);setPage(previous=>Math.min(previous,Math.max(0,next.length-1)));
  }
  const observer=new ResizeObserver(layout);observer.observe(host);layout();
  let disposed=false;document.fonts.ready.then(()=>{if(!disposed)layout()});
  return()=>{disposed=true;observer.disconnect()};
 },[blocks]);
 useEffect(()=>setPage(0),[word.id,flipped]);
 function content(block:Block,index:number){return <div key={index} className={`pocket-block pocket-${block.kind}`} lang={block.lang}>{block.kind==='word'?<button aria-label="翻转卡片" onClick={onFlip}>{block.text}</button>:block.text}</div>}
 return <div className={`pocket-card${flipped?'':' pocket-card-front'}`}>
  <div className="pocket-stage" ref={stage}>
   <div className="pocket-measure" ref={measure} aria-hidden="true" inert>{blocks.map(content)}</div>
   <div className="pocket-page" aria-live="polite">{(pages[page]||[]).map(content)}</div>
  </div>
  <div className={`pocket-pagination${pages.length>1?'':' pocket-pagination-single'}`}>{pages.length>1&&<><button disabled={page===0} onClick={()=>setPage(i=>i-1)} aria-label="上一页内容">← 上一页</button><span>{page+1} / {pages.length}</span><button disabled={page===pages.length-1} onClick={()=>setPage(i=>i+1)} aria-label="下一页内容">{page===0?'更多内容':'下一页'} →</button></>}</div>
 </div>
}
