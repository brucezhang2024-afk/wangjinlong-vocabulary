// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {empty,queue,rate,parseProgress,day} from './learning.ts';
const words=Array.from({length:12},(_,i)=>({id:String(i),word:'단어',level:'初级',pos:'名词',definition:'单词'}));
const now=new Date('2026-10-10T09:00:00+08:00');
test('每日额度、已学排除与到期复习优先',()=>{let p=empty();p.limit=2;assert.equal(queue(words,p,now).length,2);p=rate(p,'0',3,now);p=rate(p,'1',4,now);assert.equal(queue(words,p,now).length,0);const later=new Date(+now+86400000*10);assert.equal(queue(words,p,later)[0].id,'0');assert.equal(queue(words,p,later).length,4)});
test('遗忘后短期再次复习，备份往返保存日期',()=>{const p=rate(empty(),'0',1,now);assert.ok(+p.cards['0'].due>+now);assert.ok(+p.cards['0'].due<+now+3600000);const restored=parseProgress(JSON.stringify(p),new Set(words.map(w=>w.id)));assert.ok(restored.cards['0'].due instanceof Date);assert.deepEqual(restored,p);assert.equal(queue(words,restored,new Date(+now+600000))[0].id,'0')});
test('不合法备份拒绝，四档 FSRS 都输出未来时间',()=>{assert.throws(()=>parseProgress('{"version":2}',new Set()));for(const rating of [1,2,3,4])assert.ok(+rate(empty(),'0',rating,now).cards['0'].due>+now);const p=rate(empty(),'0',3,now);p.cards['0'].stability=-1;assert.throws(()=>parseProgress(JSON.stringify(p),new Set(['0'])))});
test('本地日期生成每天独立配额',()=>{assert.match(day(now),/^\d{4}-\d{2}-\d{2}$/);let p=rate(empty(),'0',4,now);p.limit=1;assert.equal(queue(words,p,now).length,0);assert.equal(queue(words,p,new Date(+now+86400000)).filter(w=>!p.cards[w.id]).length,1)});

test('新词跨全库随机、同日稳定、不依赖目录顺序，下一日重新抽取',()=>{
 const all=Array.from({length:100},(_,i)=>({...words[0],id:`card-${i}`,level:['初级','中级','高级','附录'][Math.floor(i/25)]}));
 const p=empty();p.limit=20;const today=queue(all,p,now,'test-device');
 assert.deepEqual(today,queue([...all].reverse(),p,now,'test-device'));
 assert.notDeepEqual(today.map(w=>w.id),all.slice(0,20).map(w=>w.id));
 assert.equal(new Set(today.map(w=>w.level)).size,4);
 assert.notDeepEqual(today,queue(all,p,new Date(+now+86400000),'test-device'));
 const learned=rate(p,today[0].id,4,now);const remaining=queue(all,learned,now,'test-device');
 assert.deepEqual(remaining,today.slice(1));
});
