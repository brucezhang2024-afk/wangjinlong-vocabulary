// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {buildCardAliases,empty,parseProgress,queue,rate} from './learning.ts';
import {hasLearned,libraryWords,wordOrigins} from './library.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const manifest=JSON.parse(readFileSync(new URL('./dedup-manifest.json',import.meta.url),'utf8'));
const round2=JSON.parse(readFileSync(new URL('./dedup-20261109-manifest.json',import.meta.url),'utf8'));
const aliases=buildCardAliases(words),ids=new Set(words.map(w=>w.id));
const originals=new Map(words.flatMap(wordOrigins).map(w=>[w.id,w]));
const stable=value=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,stable(value[k])])):value;
const first=new Date('2026-10-26T08:00:00Z'),later=new Date('2026-10-27T08:00:00Z');

test('approved groups reduce 389 learning cards while every original source card remains byte-equivalent in canonical form',()=>{
 assert.equal(Object.keys(aliases).length,round2.totalAliases);assert.equal(words.filter(w=>w.legacyIds).length,round2.totalMergedGroups);
 assert.ok(words.length>=manifest.afterCards);
 const restored=manifest.originalCardIds.map(id=>originals.get(id));
 assert.equal(restored.length,15277);assert.ok(restored.every(Boolean));
 assert.equal(createHash('sha256').update(JSON.stringify(stable(restored))).digest('hex'),manifest.originalCardsSha256);
 for(const [canonical,oldIds] of Object.entries(manifest.mergedGroups)){
  assert.ok(ids.has(canonical));for(const old of oldIds){assert.equal(aliases[old],canonical);assert.ok(!ids.has(old));}
 }
});

test('merged learning cards retain all Korean-Chinese examples, credits and collocations',()=>{
 for(const word of words.filter(w=>w.sourceCards)){
  for(const old of word.sourceCards){
   for(const e of old.examples||[]){
    const match=word.examples.find(n=>n.kr===e.kr&&n.cn===e.cn&&(n.grammar||'')===(e.grammar||''));
    assert.ok(match,`${old.id}: example lost`);if(e.source)assert.ok(match.source?.includes(e.source));
   }
   for(const field of ['synonyms','antonyms','extensions','collocations'])
    for(const item of old[field]||[])assert.ok(word[field].includes(item),`${old.id}: ${field}`);
  }
 }
});

test('merging preserves the retained definition instead of narrowing it to an appendix qualifier',()=>{
 const preferred={'감탄하다':'赞叹，惊叹','에너지':'能源、能量；精力、活力'};
 for(const word of words.filter(w=>Object.hasOwn(manifest.mergedGroups,w.id)))
  assert.equal(word.definition,preferred[word.word]||word.sourceCards[0].definition);
 assert.equal(words.find(w=>w.word==='지적하다').definition,'指出');
 assert.equal(words.find(w=>w.word==='만나다').definition,'遇到，相逢');
});

test('old alias-only backups retain FSRS state and all events without relearning the same word',()=>{
 const old='BOOK-2347',canonical=aliases[old];const original=rate(empty(),old,3,first);
 const restored=parseProgress(JSON.stringify(original),ids,aliases);
 assert.deepEqual(restored.cards[canonical],original.cards[old]);assert.ok(!restored.cards[old]);
 assert.deepEqual(restored.events,original.events);assert.deepEqual(restored.mergeArchive[old],original.cards[old]);
 const pool=words.filter(w=>w.id===canonical);
 assert.equal(queue(pool,restored,first).length,0);
 assert.equal(queue(pool,restored,new Date(+first+30*86400000)).length,1);
 assert.equal(parseProgress(JSON.stringify(restored),ids,aliases).events.length,1);
});

test('conflicting schedules use the latest real review and archive both originals, without inventing review counts',()=>{
 const old='BOOK-2347',canonical=aliases[old];let p=rate(empty(),canonical,4,first);p=rate(p,old,1,later);
 const restored=parseProgress(JSON.stringify(p),ids,aliases);
 assert.deepEqual(restored.cards[canonical],p.cards[old]);assert.equal(restored.cards[canonical].reps,p.cards[old].reps);
 assert.deepEqual(restored.mergeArchive[canonical],p.cards[canonical]);assert.deepEqual(restored.mergeArchive[old],p.cards[old]);
 assert.deepEqual(restored.events,p.events);
 const archive=JSON.stringify(restored.mergeArchive);rate(restored,canonical,3,new Date(+later+600000));
 assert.equal(JSON.stringify(restored.mergeArchive),archive);
 assert.deepEqual(parseProgress(JSON.stringify(restored),ids,aliases),restored);
});

test('a newer canonical review wins and ties prefer the earlier due date',()=>{
 const old='BOOK-2347',canonical=aliases[old];let p=rate(empty(),old,1,first);p=rate(p,canonical,4,later);
 assert.deepEqual(parseProgress(JSON.stringify(p),ids,aliases).cards[canonical],p.cards[canonical]);
 const tied=rate(rate(empty(),old,1,first),canonical,4,first);
 assert.deepEqual(parseProgress(JSON.stringify(tied),ids,aliases).cards[canonical],tied.cards[old]);
});

test('every retired ID migrates, including groups with several old cards, while all original states and events survive',()=>{
 const p=empty(),expected=new Map();
 const template=rate(empty(),'sample',3,first).cards.sample;
 for(const [canonical,oldIds] of Object.entries(manifest.mergedGroups)){
  for(const [i,id] of [canonical,...oldIds].entries()){
   const card={...structuredClone(template),last_review:new Date(+first+i*60000),due:new Date(+later+i*60000),reps:i+1};
   p.cards[id]=card;p.events.push({id,at:card.last_review.toISOString(),rating:3,isNew:true});expected.set(canonical,card);
  }
 }
 const restored=parseProgress(JSON.stringify(p),ids,aliases);
 assert.equal(Object.keys(p.cards).length,763);assert.equal(Object.keys(restored.cards).length,374);
 assert.equal(Object.keys(restored.mergeArchive).length,763);assert.deepEqual(restored.events,p.events);
 for(const [id,card] of expected)assert.deepEqual(restored.cards[id],card);
 for(const [id,card] of Object.entries(p.cards))assert.deepEqual(restored.mergeArchive[id],card);
 assert.deepEqual(parseProgress(JSON.stringify(restored),ids,aliases),restored);
});

test('legacy events preserve the daily new-card limit, and unknown IDs or corrupt archives are rejected',()=>{
 const p=rate(rate(empty(),'BOOK-1966',3,later),'BOOK-2347',3,later);p.limit=2;
 const restored=parseProgress(JSON.stringify(p),ids,aliases);
 assert.equal(restored.events.length,2);assert.equal(Object.keys(restored.cards).length,1);
 assert.equal(queue(words,restored,later).filter(w=>!restored.cards[w.id]).length,0);
 const bad=rate(empty(),'unknown-card',3,first);assert.throws(()=>parseProgress(JSON.stringify(bad),ids,aliases));
 restored.mergeArchive['BOOK-2347'].stability=-1;assert.throws(()=>parseProgress(JSON.stringify(restored),ids,aliases));
});

test('TOPIK source text stays complete, old learned aliases mark source rows learned, and distinct senses remain separate',()=>{
 const view=libraryWords(words,'TOPIK真题');assert.equal(view.length,7381);
 const previous=manifest.originalCardIds.map(id=>originals.get(id));const oldView=libraryWords(previous,'TOPIK真题');
 assert.deepEqual(view.map(({id,learningIds,...text})=>text),oldView.map(({id,learningIds,...text})=>text));
 const p=parseProgress(JSON.stringify(rate(empty(),'TOPIK-e4c512cd44b9e2a7f788',3,first)),ids,aliases);
 const source=view.find(w=>w.word==='감탄하다');assert.ok(hasLearned(source,p));
 for(const head of ['가사','영상','위'])assert.equal(words.filter(w=>w.word===head).length,2);
 for(const head of ['곤충','타협','착각하다'])assert.equal(words.filter(w=>w.word===head).length,1);
 assert.equal(words.flatMap(wordOrigins).filter(w=>w.source==='TOPIK10000').length,3869);
});

test('original units remain searchable without putting duplicate cards back into learning',()=>{
 for(const level of ['初级','中级','高级','附录'])for(const unit of ['全部单元',...Array.from({length:20},(_,i)=>String(i+1))]){
  const view=libraryWords(words,level,unit);
  const expected=words.filter(w=>wordOrigins(w).some(o=>o.level===level&&(unit==='全部单元'||String(o.unit)===unit)));
  assert.deepEqual(view.map(w=>w.id),expected.map(w=>w.id));
  assert.equal(new Set(view.map(w=>w.id)).size,view.length);
 }
});
