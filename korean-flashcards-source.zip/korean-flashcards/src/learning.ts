import { createEmptyCard, fsrs, type Card, type Grade } from 'ts-fsrs';
export type Word = {id:string;word:string;level:string;pos:string;definition:string;legacyIds?:string[];sourceCards?:Word[];topikNumber?:number;topikEntry?:{word:string;pos:string;definition:string;collocations:string[];examples?:{kr:string;cn:string;grammar?:string;source?:string}[]};bookNumber?:number;unit?:number;sourcePage?:number;reviewStatus?:string;source?:string;sourceNote?:string;importSources?:{book:string;file:string;section:string}[];synonyms?:string[];antonyms?:string[];extensions?:string[];pronunciation?:string;hanja?:string;collocations?:string[];examples?:{kr:string;cn:string;grammar?:string;source?:string}[];topik10000Number?:number;senses?:{senseKey:string;definition:string;pos:string;frame:string;usageNote:string;examples:{kr:string;cn:string;source?:string}[]}[]};
export type Progress = {version:1;cards:Record<string,Card>;events:{id:string;at:string;rating:number;isNew:boolean}[];limit:number;mergeArchive?:Record<string,Card>};
export function buildCardAliases(words:Word[]):Record<string,string>{
 const aliases:Record<string,string>=Object.create(null),ids=new Set(words.map(w=>w.id));
 for(const word of words)for(const old of word.legacyIds||[]){
  if(ids.has(old)||(aliases[old]&&aliases[old]!==word.id))throw Error('词卡关联配置不正确');
  aliases[old]=word.id;
 }
 return aliases;
}
export const empty = ():Progress => ({version:1,cards:{},events:[],limit:10});
export const day = (d:Date) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
export const scheduler=fsrs({enable_fuzz:false});
// A daily seeded rank keeps the queue random without changing cards on every render.
function randomRank(value:string){
 let h=2166136261;
 for(let i=0;i<value.length;i++){h^=value.charCodeAt(i);h=Math.imul(h,16777619)}
 h^=h>>>16;h=Math.imul(h,0x85ebca6b);h^=h>>>13;h=Math.imul(h,0xc2b2ae35);return (h^(h>>>16))>>>0;
}
export function queue(words:Word[],p:Progress,now=new Date(),seed='daily') {
 const used=p.events.filter(e=>e.isNew&&day(new Date(e.at))===day(now)).length;
 const due=words.filter(w=>p.cards[w.id]&&new Date(p.cards[w.id].due)<=now).sort((a,b)=>+new Date(p.cards[a.id].due)-+new Date(p.cards[b.id].due));
 const prefix=`${seed}:${day(now)}:`;
 const fresh=words.filter(w=>!p.cards[w.id]).sort((a,b)=>randomRank(prefix+a.id)-randomRank(prefix+b.id)||a.id.localeCompare(b.id));
 return [...due,...fresh.slice(0,Math.max(0,p.limit-used))];
}
export function rate(p:Progress,id:string,rating:Grade,now=new Date()):Progress {
 const result=scheduler.next(p.cards[id]||createEmptyCard(now),now,rating);
 return {...p,cards:{...p.cards,[id]:result.card},events:[...p.events,{id,at:now.toISOString(),rating,isNew:!p.cards[id]}]};
}
export function parseProgress(raw:string,ids:Set<string>,aliases:Record<string,string>={}):Progress {
 const p=JSON.parse(raw);
 if(p.version!==1||!p.cards||typeof p.cards!=='object'||Array.isArray(p.cards)||!Array.isArray(p.events)||!Number.isInteger(p.limit)||p.limit<1||p.limit>100)throw Error('备份格式不正确');
 const known=(id:string)=>ids.has(Object.hasOwn(aliases,id)?aliases[id]:id);
 function validateCards(cards:Record<string,Card>){
 for(const [id,value] of Object.entries(cards)){
  const c=value as Card;
  if(!known(id)||!c||![0,1,2,3].includes(c.state)||['stability','difficulty','elapsed_days','scheduled_days','learning_steps','reps','lapses'].some(k=>typeof (c as any)[k]!=='number'||!Number.isFinite((c as any)[k])||(c as any)[k]<0))throw Error('卡片数据不正确');
  c.due=new Date(c.due);if(isNaN(+c.due))throw Error('复习时间不正确');
  if(c.last_review){c.last_review=new Date(c.last_review);if(isNaN(+c.last_review))throw Error('复习记录不正确');}
 }
 }
 validateCards(p.cards);
 if(p.mergeArchive!==undefined){
  if(!p.mergeArchive||typeof p.mergeArchive!=='object'||Array.isArray(p.mergeArchive))throw Error('合并前记录不正确');
  validateCards(p.mergeArchive);
 }
 if(p.events.some((e:any)=>!e||!known(e.id)||!Number.isFinite(Date.parse(e.at))||![1,2,3,4].includes(e.rating)||typeof e.isNew!=='boolean'))throw Error('学习记录不正确');
 // Keep every practice event and original FSRS state; use the most recent real
 // review as the active schedule instead of fabricating an averaged memory state.
 const originalCards={...p.cards};
 for(const id of Object.keys(originalCards))if(Object.hasOwn(aliases,id)){
  const target=aliases[id],incoming=p.cards[id] as Card,current=p.cards[target] as Card|undefined;
  const archive=p.mergeArchive??(p.mergeArchive={});
  archive[id]??=structuredClone(incoming);
  if(originalCards[target])archive[target]??=structuredClone(originalCards[target]);
  const reviewed=(c:Card)=>c.last_review?+new Date(c.last_review):0;
  if(!current||reviewed(incoming)>reviewed(current)||
     (reviewed(incoming)===reviewed(current)&&+incoming.due<+current.due))p.cards[target]=incoming;
  delete p.cards[id];
 }
 return p;
}
