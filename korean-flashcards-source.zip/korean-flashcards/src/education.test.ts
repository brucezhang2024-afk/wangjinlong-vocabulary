// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {libraryWords,matchesLibraryQuery} from './library.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const card=id=>words.find(w=>w.id===id);

test('education reference additions have independent IDs, complete bilingual examples and explicit example credits',()=>{
 const additions=words.filter(w=>w.id.startsWith('NIKL2017-'));
 assert.ok(additions.length>=1844);
 assert.equal(new Set(words.map(w=>w.id)).size,words.length);
 for(const w of additions){
  assert.ok(w.pos&&w.definition&&w.collocations.length&&w.examples.length);
  for(const e of w.examples){
   assert.match(e.kr,/[가-힣]/);assert.match(e.cn,/[\u3400-\u9fff]/);
   assert.match(e.source,/非原书/);assert.doesNotMatch(e.kr,/[\u3400-\u9fff]/);
  }
 }
});

test('related forms find the correct existing sense without adding another learning card or changing TOPIK source rows',()=>{
 const imports=card('APP-323-034'),income=card('APP-323-033');
 const poetry=card('APP-323-036'),time=card('APP-323-035');
 assert.ok(matchesLibraryQuery(imports,'수입품'));assert.ok(!matchesLibraryQuery(income,'수입품'));
 assert.ok(matchesLibraryQuery(poetry,'시적（'));assert.ok(!matchesLibraryQuery(time,'시적（'));
 assert.equal(words.filter(w=>w.word==='수입품').length,0);
 assert.equal(words.filter(w=>w.word==='바라다보다').length,0);
 assert.ok(matchesLibraryQuery(card('TOPIK-c09f5b5d3ee043cc11f8'),'바라다보다'));
 assert.equal(libraryWords(words,'TOPIK真题').length,7381);
 const before=imports.sourceCards.find(w=>w.id===imports.id);
 assert.equal(before.definition,imports.definition);
 assert.ok(!matchesLibraryQuery(before,'수입품'));
});

test('new homograph cards keep colours, judo and excrement separate from unrelated existing senses',()=>{
 const colour=words.find(w=>w.id.startsWith('NIKL2017-')&&w.word==='자주색');
 const judo=words.find(w=>w.id.startsWith('NIKL2017-')&&w.word==='유도');
 const excrement=words.find(w=>w.id.startsWith('NIKL2017-')&&w.word==='대변');
 assert.match(colour.definition,/紫/);assert.match(judo.definition,/柔道/);assert.match(excrement.definition,/粪|大便/);
 assert.match(card('TOPIK-86af4ee1208686716b27').extensions.join(' '),/유도（名词）：引导/);
 assert.match(card('TOPIK-30dddedef9ef0e4b7008').extensions.join(' '),/대변（名词）：代言/);
 assert.ok(words.some(w=>w.word==='최우수'&&w.id.startsWith('NIKL2017-')));
});
