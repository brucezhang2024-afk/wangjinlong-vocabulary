// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildCardAliases,empty,parseProgress,queue,rate} from './learning.ts';
import {hasLearned,libraryWords,matchesLibraryQuery,wordOrigins} from './library.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const manifest=JSON.parse(readFileSync(new URL('./dedup-20261109-manifest.json',import.meta.url),'utf8'));
const aliases=buildCardAliases(words),ids=new Set(words.map(w=>w.id)),by=new Map(words.map(w=>[w.id,w]));
const first=new Date('2026-11-08T08:00:00Z'),later=new Date('2026-11-09T08:00:00Z');

test('approved 83 retired cards map to 79 retained cards and their forms remain searchable',()=>{
 assert.equal(Object.keys(manifest.mergedGroups).length,79);
 assert.equal(Object.values(manifest.mergedGroups).flat().length,83);
 assert.equal(Object.keys(aliases).length,472);assert.ok(words.length>=19747);
 for(const [target,oldIds] of Object.entries(manifest.mergedGroups)){
  const card=by.get(target);assert.ok(card);assert.equal(card.definition,manifest.definitions[target]);
  for(const old of oldIds){assert.equal(aliases[old],target);assert.ok(!ids.has(old));}
 }
 for(const [oldHead,newHead] of Object.entries(manifest.formAliases)){
  const target=words.find(w=>w.word===newHead);assert.ok(matchesLibraryQuery(target,oldHead),oldHead);
  assert.ok(wordOrigins(target).some(w=>w.word===oldHead));
  assert.ok(!words.some(w=>w.word===oldHead));
 }
});

test('every new retired ID keeps its real FSRS state, conflicts and full practice history',()=>{
 let p=empty();const expected=new Map();
 for(const [target,oldIds] of Object.entries(manifest.mergedGroups)){
  p=rate(p,target,4,first);
  for(const old of oldIds){p=rate(p,old,1,later);expected.set(target,p.cards[old]);}
 }
 const prior=structuredClone(p),restored=parseProgress(JSON.stringify(p),ids,aliases);
 assert.equal(Object.keys(prior.cards).length,162);assert.equal(Object.keys(restored.cards).length,79);
 assert.equal(Object.keys(restored.mergeArchive).length,162);assert.deepEqual(restored.events,prior.events);
 for(const [target,oldIds] of Object.entries(manifest.mergedGroups)){
  assert.deepEqual(restored.cards[target],expected.get(target));
  for(const old of oldIds)assert.deepEqual(restored.mergeArchive[old],prior.cards[old]);
 }
 assert.deepEqual(parseProgress(JSON.stringify(restored),ids,aliases),restored);
 const active=words.filter(w=>Object.hasOwn(manifest.mergedGroups,w.id));
 const due=queue(active,restored,new Date(+later+30*86400000));
 assert.equal(due.length,79);assert.equal(new Set(due.map(w=>w.id)).size,79);
});

test('wider meanings and later approved forms remain visible after merging narrow cards',()=>{
 for(const [id,needles] of [
  ['BOOK-1817',['首映','拆封']],['BOOK-0596',['紧紧','务必']],['BOOK-0368',['合身','正确']],
  ['BOOK-2716',['达到','影响']],['BOOK-1287',['马上','正是','径直']],
  ['BOOK-0832',['快','早']],['BOOK-0807',['容易','很可能']],['BOOK-1507',['柔软','浅']],
  ['BOOK-1372',['相册','专辑']],['BOOK-1280',['意识','清醒']],
 ]){
  const c=by.get(id);for(const needle of needles)assert.ok(c.senses.some(s=>s.definition.includes(needle)),`${id} ${needle}`);
 }
 assert.ok(matchesLibraryQuery(by.get('BOOK-1287'),'바로바로'));
 assert.ok(matchesLibraryQuery(by.get('BOOK-0919'),'양적'));
 for(const head of manifest.distinctHeadsRetained)assert.equal(words.filter(w=>w.word===head).length,2,head);
 assert.ok(by.has('APP-322-026'));assert.equal(by.get('APP-322-026').definition,'疯');
 for(const id of ['BOOK-0481','BOOK-0571','BOOK-1029','BOOK-0552','BOOK-0828','BOOK-0238','BOOK-0532','BOOK-1910','BOOK-1761','BOOK-1376','BOOK-0365','BOOK-2285','BOOK-1183','BOOK-1749','BOOK-0420'])assert.ok(by.has(id),id);
});

test('TOPIK10000 and all source categories retain entries and share migrated learning status',()=>{
 const view=libraryWords(words,'TOPIK10000');assert.equal(view.length,3869);
 const form=view.find(w=>w.topik10000Number===2230);assert.equal(form.word,'연이어');
 assert.equal(form.id,'TOPIK10000-2230');assert.equal(form.learningIds[0],aliases[form.id]);
 const p=parseProgress(JSON.stringify(rate(empty(),form.id,3,later)),ids,aliases);
 assert.ok(hasLearned(form,p));assert.ok(!p.cards[form.id]);
 assert.equal(libraryWords(words,'TOPIK真题').length,7381);
 assert.equal(libraryWords(words,'韩语原版商业书籍').length,3584);
 assert.equal(libraryWords(words,'韩剧台词本').length,504);
 for(const c of words.filter(w=>Object.hasOwn(manifest.mergedGroups,w.id))){
  const k=e=>JSON.stringify([e.kr,e.cn,e.grammar||'']);
  assert.deepEqual(new Set(c.examples.map(k)),new Set(c.senses.flatMap(s=>s.examples).map(k)),c.id);
 }
});
