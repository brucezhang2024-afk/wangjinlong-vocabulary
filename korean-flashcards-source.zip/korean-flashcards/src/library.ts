import type {Word,Progress} from './learning.ts';
export type LibraryWord=Word&{learningIds?:string[]};
export function wordOrigins(word:Word):Word[]{return word.sourceCards||[word]}
export function matchesLibraryQuery(word:Word,query:string):boolean{
 const sourceText=wordOrigins(word).map(s=>`${s.word} ${s.definition} ${s.bookNumber||''}`).join(' ');
 const text=[word.word,word.definition,sourceText,...word.synonyms||[],...word.antonyms||[],...word.extensions||[],
  word.topikNumber?String(word.topikNumber).padStart(4,'0'):word.bookNumber||''].join(' ');
 return text.includes(query);
}
// The source-list view represents original entries, independent of the study-card order.
export function libraryWords(words:Word[],level:string,unit='全部单元'):LibraryWord[]{
 if(['韩语原版商业书籍','韩剧台词本','TOPIK10000'].includes(level)){
 const entries=words.flatMap(canonical=>wordOrigins(canonical)
  .filter(origin=>origin.level===level&&(unit==='全部单元'||String(origin.unit)===unit))
  .map(origin=>({...(origin.id===canonical.id?canonical:origin),learningIds:[canonical.id]})));
 return level==='TOPIK10000'?entries.sort((a,b)=>(a.topik10000Number||0)-(b.topik10000Number||0)):entries;
 }
 if(level!=='TOPIK真题')return words.flatMap(w=>{
  if(level==='全部'&&unit==='全部单元')return [w];
  const matches=(entry:Word)=>(level==='全部'||entry.level===level)&&(unit==='全部单元'||String(entry.unit)===unit);
  const origin=wordOrigins(w).find(matches);
  if(!origin)return [];
  if(matches(w))return [w];
  return [{...w,level:origin.level,unit:origin.unit,bookNumber:origin.bookNumber,sourcePage:origin.sourcePage}];
 });
 const groups=new Map<number,{origin:Word;canonical:Word}[]>();
 for(const canonical of words)for(const origin of wordOrigins(canonical))if(origin.topikNumber){
  const group=groups.get(origin.topikNumber)||[];group.push({origin,canonical});groups.set(origin.topikNumber,group);
 }
 return [...groups].sort(([a],[b])=>a-b).map(([number,group])=>{
  const entry=group.find(w=>w.origin.topikEntry)||group[0],card=entry.origin;const source=card.topikEntry||card;
  return {id:entry.canonical.id,word:source.word,pos:source.pos,definition:source.definition,level:'TOPIK真题',topikNumber:number,
   source:'TOPIK 公开真题词表',sourceNote:`TOPIK 公开真题词表 · 第 ${number} 条`,
   examples:card.topikEntry?.examples??card.examples?.filter(e=>e.source?.startsWith('TOPIK 公开真题词表 · ')),collocations:source.collocations,
   learningIds:[...new Set(group.map(w=>w.canonical.id))]};
 });
}
export function hasLearned(word:LibraryWord,p:Progress){return (word.learningIds||[word.id]).some(id=>!!p.cards[id])}
