import type {Word,Progress} from './learning.ts';
export type LibraryWord=Word&{learningIds?:string[]};
// The source-list view represents original entries, independent of the study-card order.
export function libraryWords(words:Word[],level:string,unit='全部单元'):LibraryWord[]{
 if(level!=='TOPIK真题')return words.filter(w=>(level==='全部'||w.level===level)&&(unit==='全部单元'||String(w.unit)===unit));
 const groups=new Map<number,Word[]>();
 for(const w of words)if(w.topikNumber){const group=groups.get(w.topikNumber)||[];group.push(w);groups.set(w.topikNumber,group)}
 return [...groups].sort(([a],[b])=>a-b).map(([number,group])=>{
  const card=group.find(w=>w.topikEntry)||group[0];const source=card.topikEntry||card;
  return {id:card.id,word:source.word,pos:source.pos,definition:source.definition,level:'TOPIK真题',topikNumber:number,
   source:'TOPIK 公开真题词表',sourceNote:`TOPIK 公开真题词表 · 第 ${number} 条`,
   examples:card.examples?.filter(e=>e.source?.startsWith('TOPIK 公开真题词表 · ')),collocations:source.collocations,
   learningIds:group.map(w=>w.id)};
 });
}
export function hasLearned(word:LibraryWord,p:Progress){return (word.learningIds||[word.id]).some(id=>!!p.cards[id])}
