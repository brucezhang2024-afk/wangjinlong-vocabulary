// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {libraryWords,matchesLibraryQuery,hasLearned,wordOrigins} from './library.ts';
import {empty,rate,parseProgress,buildCardAliases} from './learning.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const view=libraryWords(words,'韩剧台词本'),by=new Map(words.map(w=>[w.id,w]));
test('drama source forms are browsable without creating duplicate learning cards',()=>{
 assert.equal(words.filter(w=>w.id.startsWith('MISAENG-')).length,210);
 assert.equal(view.length,504);assert.equal(new Set(view.map(w=>w.id)).size,504);
 assert.equal(view.filter(w=>w.learningIds[0]!==w.id).length,294);
 assert.equal(view.filter(w=>w.word==='블루칼라').length,1);
 assert.deepEqual(view.filter(w=>!w.learningIds.length).map(w=>w.word).sort(),['기면','노후하다','대박한 거지','상사형'].sort());
 for(const w of view){
  assert.equal(w.level,'韩剧台词本');assert.ok(w.examples.length&&w.collocations.length);
  for(const e of w.examples){assert.ok(e.kr&&e.cn);assert.match(e.source,/非原书/)}
  if(!w.learningIds.length)continue;
  assert.equal(w.learningIds.length,1);
  assert.ok(by.has(w.learningIds[0]));assert.ok(matchesLibraryQuery(by.get(w.learningIds[0]),w.word));
 }
 assert.equal(libraryWords(words,'TOPIK真题').length,7381);
 assert.equal(libraryWords(words,'韩语原版商业书籍').length,3584);
});
test('related words use the correct homograph and retain the existing learned record',()=>{
 for(const [head,expected] of [['수입자','APP-323-034'],['큰형','APP-326-024'],['형아','APP-326-024'],['미친놈','APP-322-026'],['처먹다','APP-322-019'],['진정되다','TOPIK-c2b9823c20570cf8755b']]){
  const w=view.find(x=>x.word===head);assert.equal(w.learningIds[0],expected,head);
  const p=rate(empty(),expected,3);assert.ok(hasLearned(w,p));assert.equal(p.cards[w.id],undefined);
  const restored=parseProgress(JSON.stringify(p),new Set(by.keys()),buildCardAliases(words));assert.ok(hasLearned(w,restored));assert.equal(restored.events.length,1);
 }
});
test('confirmed drama senses preserve original meanings, examples and source snapshots',()=>{
 for(const id of ['TOPIK-3f663e28cb8bea91b2ae','TOPIK10000-0522','EXAMPLE-5948d5a94d32c6c72514','READ30-ab7e4b5738938c6d1242']){
  const w=by.get(id),original=wordOrigins(w)[0];assert.equal(original.id,id);assert.ok(w.definition.startsWith(original.definition+'；'));
  assert.ok(w.senses.some(s=>s.definition===original.definition));
  for(const e of original.examples)assert.ok(w.examples.some(x=>x.kr===e.kr&&x.cn===e.cn));
 }
 assert.match(by.get('TOPIK-3f663e28cb8bea91b2ae').definition,/审计/);
 assert.match(by.get('TOPIK10000-0522').definition,/棋院.*起源/);
 assert.ok(!view.some(w=>['커패','새빠시','유전스'].includes(w.word)));
});
