// @ts-nocheck
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {libraryWords,wordOrigins} from './library.ts';
import {empty,queue,rate,parseProgress,buildCardAliases} from './learning.ts';
const words=JSON.parse(readFileSync(new URL('./vocabulary.json',import.meta.url),'utf8'));
const category='韩语原版商业书籍';
const norm=s=>s.normalize('NFKC').replace(/[\s^\-]/g,'').toLowerCase();
test('business-book category contains reviewed new heads, excludes old heads and participates in random learning',()=>{
 const view=libraryWords(words,category),old=words.filter(w=>!w.id.startsWith('READ3-'));
 assert.equal(view.length,1299);assert.ok(view.every(w=>w.id.startsWith('READ3-')&&w.level===category));
 const oldHeads=new Set(old.map(w=>norm(w.word)));
 assert.equal(new Set(view.map(w=>norm(w.word))).size,1299);
 for(const w of view){
  assert.ok(!oldHeads.has(norm(w.word)),w.word);assert.ok(w.definition&&w.collocations.length&&w.examples.length);
  for(const e of w.examples){assert.match(e.kr,/[가-힣]/);assert.match(e.cn,/[\u4e00-\u9fff]/);assert.match(e.source,/非原书/);}
 }
 const p=empty(),now=new Date('2026-11-07T03:00:00Z');
 for(const w of old)p.cards[w.id]={...rate(empty(),w.id,3,now).cards[w.id]};
 assert.ok(queue(words,p,now,'reading').every(w=>w.level===category));
 assert.equal(libraryWords(words,'TOPIK真题').length,7381);
});
test('approved extra senses preserve original meanings, examples, source views and learned IDs',()=>{
 const targets=['공정','공기','장','지대','고지','주식','복리','공식','수위','날','고도'];
 const cards=words.filter(w=>targets.includes(w.word)&&w.sourceNote?.includes('韩语原版商业书籍确认补义：'));
 assert.equal(cards.length,11);
 const ids=new Set(words.map(w=>w.id)),aliases=buildCardAliases(words);
 for(const w of cards){
  const old=wordOrigins(w)[0];assert.equal(old.id,w.id);assert.ok(w.definition.startsWith(old.definition+'；'));
  for(const e of old.examples)assert.ok(w.examples.some(n=>JSON.stringify(n)===JSON.stringify(e)));
  assert.ok(w.senses.some(s=>s.definition===old.definition));assert.ok(w.senses.length>1);
  const learned=rate(empty(),w.id,3);assert.ok(parseProgress(JSON.stringify(learned),ids,aliases).cards[w.id]);
 }
 const source=libraryWords(words,'TOPIK真题');
 assert.ok(!source.find(w=>w.word==='날').definition.includes('刀刃'));
 assert.ok(!source.find(w=>w.word==='수위').definition.includes('首位'));
});
